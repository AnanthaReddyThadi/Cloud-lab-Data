package JpestStorePages;

import java.io.File;



import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.io.FileHandler;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class Baseclass {
    WebDriver driver;
    ExtentReports extent;
    ExtentTest test;
    Properties props;

 // Setup method executed before the class starts
    
    @BeforeClass
    public void setup() throws FileNotFoundException, IOException {
    	//./extent-reports/extent-report.html
    	// Define ExtentReports and specify the report location
        ExtentSparkReporter spark = new ExtentSparkReporter("./extent-reports/extent-report.htmll");
       
        extent = new ExtentReports();
        extent.attachReporter(spark);
        
//        props = new Properties();
//        props.load(new FileInputStream("D:\\Wipro\\Project\\CapstoneProject\\src\\test\\java\\data.properties"));

        // Set ChromeDriver path and initialize WebDriver
        
        System.setProperty("webdriver.chrome.driver", "D:\\Drivers\\chromedriver.exe");
        driver = new ChromeDriver();
        
        
        // Navigate to the application URL
        driver.navigate().to("https://jpetstore.aspectran.com/");
        
        //ChromeOptions options = new ChromeOptions();
        //options.addArguments("--start-maximized");
       // driver = new ChromeDriver(options);

        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
    }
 // Method executed before each test method
    
    @BeforeMethod
    public void beforeMethod() {
    	 // Create a new test in ExtentReports for the current test method
        test = extent.createTest("Test Case: " + this.getClass().getName());
    }
    
    
    // Method executed after each test method
    @AfterMethod
    
    public void afterMethod() {
    	// Flush the ExtentReports to write all test logs to the report
        extent.flush();
    }
 // Method executed after the class ends
    @AfterClass
    public void close() {
    	// Quit WebDriver and flush ExtentReports
        driver.quit();
        extent.flush();
        
    }
    // Method to capture screenshot with given file name
    

    public void takeScreenshot(String fileName) throws IOException {
    	 // Capture screenshot and save it to a file
        File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        FileHandler.copy(screenshot, new File("./screenshots/" + fileName + ".png"));
    }
}