package JpestStorePages;

import java.io.File;
//Import necessary Java and Selenium libraries
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Duration;

import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class JpetStoreRegister {
 
 // Method to read data from Excel file
 @Test
 public void readData() throws FileNotFoundException {
     FileInputStream fis = new FileInputStream("D:\\RegisterData.xlsx"); // Path to Excel file
     
     try {
         XSSFWorkbook workbook = new XSSFWorkbook(fis); // Load workbook
         XSSFSheet sheet = workbook.getSheet("Sheet1"); // Access Sheet1
         
         int rows = sheet.getPhysicalNumberOfRows(); // Count rows
         System.out.println(rows); // Print number of rows
          
         
         int columns = sheet.getRow(0).getPhysicalNumberOfCells(); // Count columns in header row
         System.out.println(columns); // Print number of columns
         
         // Loop through rows and columns to read data
         for (int i = 0; i < rows; i++) {
             for (int j = 0; j < columns; j++) {
                 String cellData = "";
                 
                 if (sheet.getRow(i).getCell(j) != null) { // Check if cell is not null
                     if (sheet.getRow(i).getCell(j).getCellType() == CellType.NUMERIC) {
                         // Handle numeric cell
                    	 
                         double numericValue = sheet.getRow(i).getCell(j).getNumericCellValue();
                         cellData = Double.toString(numericValue); // Convert numeric to string
                     } else {
                         // Handle string cell or other types
                         cellData = sheet.getRow(i).getCell(j).getStringCellValue();
                     }
                 }
                 System.out.print(cellData + "  "); // Print cell data
             }
             System.out.println(); // Move to next line for next row
         }
         
         workbook.close(); // Close the workbook after use to release resources
     } catch (IOException e) {
         e.printStackTrace(); // Print the stack trace if an IOException occurs
     }
 }
 
 
 WebDriver driver; // WebDriver instance variable
 String baseUrl = "https://jpetstore.aspectran.com/"; // Base URL of the application
 
 // Setup method to initialize WebDriver
 
 @BeforeClass
 
 public void invokeBrowser() {
	 
     System.setProperty("webdriver.chrome.driver", "D:\\Drivers\\chromedriver.exe"); // Set ChromeDriver path
     
     driver = new ChromeDriver(); // Initialize ChromeDriver instance
     
     
     baseUrl = "https://jpetstore.aspectran.com/"; // Base URL assignment
     
     driver.manage().window().maximize(); // Maximize browser window
     
     driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10)); // Implicit wait timeout
 }
 
 // Test method to register a new user
 
 @Test(priority = 1)
 
 public void registerNewUser() throws Exception {
	 
     driver.get(baseUrl); // Open the base URL in the browser

     driver.findElement(By.linkText("Sign In")).click(); // Click on Sign In link

     driver.findElement(By.xpath("//a[normalize-space()='Register Now!']")).click(); // Click on Register Now link

     // Fill registration form fields
     driver.findElement(By.name("username")).sendKeys("Ananth1234");
     driver.findElement(By.name("password")).sendKeys("Anantha@1234");
     driver.findElement(By.name("repeatedPassword")).sendKeys("Anantha@1234");
     driver.findElement(By.name("firstName")).sendKeys("Anantha Reddy ");
     driver.findElement(By.name("lastName")).sendKeys("Thadi");
     driver.findElement(By.name("email")).sendKeys("anantha@gmail.com");
     driver.findElement(By.name("phone")).sendKeys("8889998878");
     driver.findElement(By.name("address1")).sendKeys("A-Bc123");
     driver.findElement(By.name("address2")).sendKeys("Near AMB");
     driver.findElement(By.name("city")).sendKeys("Nanadyal");
     driver.findElement(By.name("state")).sendKeys("Andra Pradesh");
     driver.findElement(By.name("zip")).sendKeys("518593");
     driver.findElement(By.name("country")).sendKeys("india");

     Thread.sleep(4000); // Pause for 4 seconds (for demo purposes)
     ScreenShots("Register Now"); // Take screenshot of the registration form

     driver.findElement(By.xpath("//button[normalize-space()='Save Account Information']")).click(); // Click Save button
     Thread.sleep(2000); // Pause for 2 seconds

     // Validate registration success
     String currentUrl = driver.getCurrentUrl(); // Get current URL
     System.out.println(currentUrl); // Print current URL
        
     
  // Get the current URL of the page after registration attempt
     String actualUrl = "https://jpetstore.aspectran.com/account/signonForm?created=true";
     System.out.println(actualUrl); // Print expected URL
     
     
     // Compare current URL with expected URL to verify if registration was successfu
     if (currentUrl.equals(actualUrl)) {
         System.out.println("RegistrationTest passed"); 
         System.out.println("Registration failed"); 
     }
 }

 // Method to close WebDriver session after all tests
 @AfterClass
 public void close1() throws InterruptedException {
     Thread.sleep(5000); // Pause for 5 seconds (for demo purposes)
     driver.quit(); // Quit the WebDriver session
 }

 // Test method to simulate invalid registration
 @Test(priority = 2)
 public void invalidRegistration() throws InterruptedException, IOException {
     driver.get(baseUrl); // Open the base URL in the browser

     driver.findElement(By.linkText("Sign In")).click(); // Click on Sign In link
     driver.findElement(By.xpath("//a[normalize-space()='Register Now!']")).click(); // Click on Register Now link

     // Enter existing username to simulate invalid registration
     driver.findElement(By.name("username")).sendKeys("existinguser");
     driver.findElement(By.name("password")).sendKeys("testpassword");
     driver.findElement(By.name("repeatedPassword")).sendKeys("testpassword");
     driver.findElement(By.name("firstName")).sendKeys("John");
     driver.findElement(By.name("lastName")).sendKeys("Doe");
     driver.findElement(By.name("email")).sendKeys("john.doe@example.com");
     driver.findElement(By.name("phone")).sendKeys("1234567ew");
     driver.findElement(By.name("address1")).sendKeys("123 Street");
     driver.findElement(By.name("city")).sendKeys("New York");
     driver.findElement(By.name("state")).sendKeys("NY");
     driver.findElement(By.name("zip")).sendKeys("10001");
     driver.findElement(By.name("country")).sendKeys("USA");

     Thread.sleep(4000); // Pause for 4 seconds (for demo purposes)
     ScreenShots("Sign In"); // Take screenshot after filling invalid registration form

     driver.findElement(By.xpath("//button[normalize-space()='Save Account Information']")).click(); // Click Save button
     Thread.sleep(2000); // Pause for 2 seconds

     // Explicit wait for error message to be visible
     WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
     
     try {
    	 
    	// Wait for the error message element to become visible on the page
    	 
         WebElement errorMessage = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("div.messages li")));
       
         
         // Assert that the error message text contains specific text indicating existing account with the same username
         assert errorMessage.getText().contains("An account already exists with the same username."); // Check error message
         
         // If assertion passes (no exceptions thrown), print a success message to the console
         System.out.println("Invalid Registration test passed."); // Print success message
     } catch (Exception e) {
    	// If any exception occurs during the above operations (element not found, assertion fails), execute this block
   
    	 System.out.println("Invalid Registration test failed. Error message not found."); 
    	 
      // Optionally, i might want to log the exception or take a screenshot here for further investigation

     }
 }
 
 // Method to take screenshot and save to file
 public void ScreenShots(String name) throws IOException {
     File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE); // Capture screenshot as File
     
     // Save screenshot to specified directory
     FileHandler.copy(screenshot, new File("./Screenshots/emptysearch.png"));
     System.out.println("Screenshot Successfully added to Images"); // Print success message
 }

 // Method to close WebDriver session after all tests
 @AfterClass
 public void close2() throws InterruptedException {
     Thread.sleep(4000); // Pause for 4 seconds (for demo purposes)
     driver.quit(); // Quit the WebDriver session
 }
}





































